from openai import AzureOpenAI
import os 
import logging
from azure.identity import DefaultAzureCredential, get_bearer_token_provider

from dotenv import load_dotenv

load_dotenv(override=True)

OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
OPENAI_API_BASE = os.getenv("AZURE_OPENAI_API_BASE")
OPENAI_MODEL = os.getenv("AZURE_OPENAI_MODEL")
OPENAI_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION")
OPENAI_API_EMBEDDING_MODEL = os.getenv("AZURE_OPENAI_API_EMBEDDING_MODEL")

print(f"OPENAI_API_KEY: ", OPENAI_API_KEY)

def get_embeddings(text):
    openai_client = AzureOpenAI(
            api_key=OPENAI_API_KEY,
            api_version=OPENAI_API_VERSION,
            azure_endpoint=OPENAI_API_BASE
            )
    
    embedding = openai_client.embeddings.create(
                 input=text,
                 model=OPENAI_API_EMBEDDING_MODEL
             ).data[0].embedding
    
    return embedding


def run_prompt(system_prompt, user_prompt):
    logging.info(f"API Key: {OPENAI_API_KEY}")
    
    openai_client = AzureOpenAI(
        api_key=OPENAI_API_KEY,
        api_version=OPENAI_API_VERSION,
        azure_endpoint=OPENAI_API_BASE
    )

    
    response = openai_client.chat.completions.create(
        model=OPENAI_MODEL,
        messages=[{ "role": "system", "content": system_prompt},
              {"role":"user","content":user_prompt}])
    
    return response.choices[0].message.content

